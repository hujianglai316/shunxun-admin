import React from 'react';
import { Card } from 'antd';

const MerchantStats: React.FC = () => {
  return (
    <Card title="数据统计">
      数据统计页面
    </Card>
  );
};

export default MerchantStats; 