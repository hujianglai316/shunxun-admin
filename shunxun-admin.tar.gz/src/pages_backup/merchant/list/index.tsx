import React from 'react';
import { Card } from 'antd';

const MerchantList: React.FC = () => {
  return (
    <Card title="商家列表">
      商家列表页面
    </Card>
  );
};

export default MerchantList; 