import React from 'react';
import { Card } from 'antd';

const UserList: React.FC = () => {
  return (
    <Card title="用户列表">
      用户列表页面
    </Card>
  );
};

export default UserList; 