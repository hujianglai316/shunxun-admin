import React from 'react';
import { Card } from 'antd';

const ContentAudit: React.FC = () => {
  return (
    <Card title="内容审核">
      <div>内容审核页面内容</div>
    </Card>
  );
};

export default ContentAudit; 