import React from 'react';
import { Card } from 'antd';

const ContentReviews: React.FC = () => {
  return (
    <Card title="评价管理">
      <div>评价管理页面内容</div>
    </Card>
  );
};

export default ContentReviews; 