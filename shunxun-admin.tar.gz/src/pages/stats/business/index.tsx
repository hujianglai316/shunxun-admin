import React from 'react';
import { Card } from 'antd';

const StatsBusiness: React.FC = () => {
  return (
    <Card title="业务分析">
      <div>业务分析页面内容</div>
    </Card>
  );
};

export default StatsBusiness; 