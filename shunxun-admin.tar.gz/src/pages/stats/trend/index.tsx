import React from 'react';
import { Card } from 'antd';

const StatsTrend: React.FC = () => {
  return (
    <Card title="趋势分析">
      <div>趋势分析页面内容</div>
    </Card>
  );
};

export default StatsTrend; 