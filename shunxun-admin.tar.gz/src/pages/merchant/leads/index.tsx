import React from 'react';
import { Card } from 'antd';

const MerchantLeads: React.FC = () => {
  return (
    <Card title="商家线索管理">
      <div>商家线索管理页面内容</div>
    </Card>
  );
};

export default MerchantLeads; 