import React from 'react';
import { Card } from 'antd';

const Dashboard: React.FC = () => {
  return (
    <Card title="仪表盘">
      仪表盘页面
    </Card>
  );
};

export default Dashboard; 