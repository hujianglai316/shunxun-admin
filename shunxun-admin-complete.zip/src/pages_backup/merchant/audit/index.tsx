import React from 'react';
import { Card } from 'antd';

const MerchantAudit: React.FC = () => {
  return (
    <Card title="商家审核">
      商家审核页面
    </Card>
  );
};

export default MerchantAudit; 