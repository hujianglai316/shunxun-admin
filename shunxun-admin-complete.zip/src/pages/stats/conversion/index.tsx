import React from 'react';
import { Card } from 'antd';

const StatsConversion: React.FC = () => {
  return (
    <Card title="转化分析">
      <div>转化分析页面内容</div>
    </Card>
  );
};

export default StatsConversion; 