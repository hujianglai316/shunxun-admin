import React from 'react';
import { Card } from 'antd';

const ContentComplaints: React.FC = () => {
  return (
    <Card title="投诉管理">
      <div>投诉管理页面内容</div>
    </Card>
  );
};

export default ContentComplaints; 