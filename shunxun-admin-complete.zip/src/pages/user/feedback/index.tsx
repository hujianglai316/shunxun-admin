import React from 'react';
import { Card } from 'antd';

const UserFeedback: React.FC = () => {
  return (
    <Card title="用户反馈">
      <div>用户反馈页面内容</div>
    </Card>
  );
};

export default UserFeedback; 