import React from 'react';
import { Card } from 'antd';

const MarketingActivities: React.FC = () => {
  return (
    <Card title="活动管理">
      <div>活动管理页面内容</div>
    </Card>
  );
};

export default MarketingActivities; 